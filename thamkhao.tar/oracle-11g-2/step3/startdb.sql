connect / as sysdba
startup
exit
